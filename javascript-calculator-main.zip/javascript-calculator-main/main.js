const keys=document.querySelectorAll('.key');
keys.forEach(key=>key.addEventListener('click',event=>handleKeyPress(event.target)));

const display=document.getElementById('display');



function handleKeyPress(key){

}